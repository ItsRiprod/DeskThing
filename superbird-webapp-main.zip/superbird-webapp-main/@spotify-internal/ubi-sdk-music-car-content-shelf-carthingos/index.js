export * from "./CarContentShelfCarthingosEventFactory.js";
