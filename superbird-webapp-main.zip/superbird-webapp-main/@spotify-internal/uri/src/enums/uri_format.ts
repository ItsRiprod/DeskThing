/**
 * The format for the URI to parse.
 */
export enum URIFormat {
  URI = 0,
  URL = 1,
}
