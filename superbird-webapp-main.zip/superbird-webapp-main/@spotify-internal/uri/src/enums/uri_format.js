/**
 * The format for the URI to parse.
 */
export var URIFormat;
(function (URIFormat) {
    URIFormat[URIFormat["URI"] = 0] = "URI";
    URIFormat[URIFormat["URL"] = 1] = "URL";
})(URIFormat || (URIFormat = {}));
