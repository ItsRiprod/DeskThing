// NOTE: This code was generated and should not be changed
/**
 * A builder for UbiExpr2PageView
 *
 * @param data - The event data
 * @return The formatted event data for UbiExpr2PageViewEvent
 */
export function createUbiExpr2PageView(data) {
    return {
        name: 'UbiExpr2PageView',
        environments: ['device', 'browser', 'desktop'],
        data,
    };
}
