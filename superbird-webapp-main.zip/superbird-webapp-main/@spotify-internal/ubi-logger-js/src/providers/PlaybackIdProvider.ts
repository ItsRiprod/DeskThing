export interface PlaybackIdProvider {
    getPlaybackId(): string | null;
}