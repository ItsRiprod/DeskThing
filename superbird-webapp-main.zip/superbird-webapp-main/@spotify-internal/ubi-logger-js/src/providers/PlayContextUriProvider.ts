export interface PlayContextUriProvider {
    getPlayContextUri(): string | null;
}