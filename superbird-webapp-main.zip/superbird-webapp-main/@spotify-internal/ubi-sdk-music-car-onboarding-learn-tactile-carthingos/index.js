export * from "./CarOnboardingLearnTactileCarthingosEventFactory.js";
