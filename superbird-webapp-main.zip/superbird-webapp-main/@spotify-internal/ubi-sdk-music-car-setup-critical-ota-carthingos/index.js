export * from "./CarSetupCriticalOtaCarthingosEventFactory.js";
