import styles from './Trailer.module.scss';

const Trailer = () => (
  <div className={styles.box}>
    <div className={styles.text}>TRAILER</div>
  </div>
);

export default Trailer;
