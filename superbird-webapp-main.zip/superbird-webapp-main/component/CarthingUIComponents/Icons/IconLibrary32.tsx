import { IconCollection } from '@spotify-internal/encore-web';

const IconLibrary32 = () => <IconCollection iconSize={32} />;

export default IconLibrary32;
