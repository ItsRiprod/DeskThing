import { IconInformationAlt } from '@spotify-internal/encore-web';

const IconInfo32 = () => <IconInformationAlt iconSize={32} />;

export default IconInfo32;
