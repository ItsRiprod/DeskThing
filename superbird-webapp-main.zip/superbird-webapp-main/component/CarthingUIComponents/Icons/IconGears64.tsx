import { IconGears } from '@spotify-internal/encore-web';

const IconGears64 = () => <IconGears iconSize={64} />;

export default IconGears64;
