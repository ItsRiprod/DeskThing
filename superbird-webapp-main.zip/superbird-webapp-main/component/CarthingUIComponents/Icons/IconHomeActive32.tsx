import { IconHomeActive } from '@spotify-internal/encore-web';

const IconHomeActive32 = () => <IconHomeActive iconSize={32} />;

export default IconHomeActive32;
