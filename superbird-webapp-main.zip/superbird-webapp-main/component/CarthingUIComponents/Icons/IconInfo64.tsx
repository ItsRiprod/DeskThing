import { IconInformationAlt } from '@spotify-internal/encore-web';

const IconInfo64 = () => <IconInformationAlt iconSize={64} />;

export default IconInfo64;
