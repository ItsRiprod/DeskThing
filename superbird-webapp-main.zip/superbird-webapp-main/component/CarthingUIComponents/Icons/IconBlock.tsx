import { IconBlock } from '@spotify-internal/encore-web';

const CarThingIconBlock = () => <IconBlock iconSize={48} />;

export default CarThingIconBlock;
