import { IconPause } from '@spotify-internal/encore-web';

const IconPause48 = () => <IconPause iconSize={48} />;

export default IconPause48;
