import { IconHeart } from '@spotify-internal/encore-web';

const IconHeart48 = () => <IconHeart iconSize={48} />;

export default IconHeart48;
