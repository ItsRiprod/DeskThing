import { IconRepeatOnce } from '@spotify-internal/encore-web';

const IconRepeatOne32 = () => <IconRepeatOnce iconSize={32} />;

export default IconRepeatOne32;
