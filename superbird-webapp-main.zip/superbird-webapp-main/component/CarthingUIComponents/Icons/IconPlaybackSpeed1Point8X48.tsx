import { IconPlaybackSpeed1Point8x } from '@spotify-internal/encore-web';

const IconPlaybackSpeed1Point8X48 = () => (
  <IconPlaybackSpeed1Point8x iconSize={48} />
);

export default IconPlaybackSpeed1Point8X48;
