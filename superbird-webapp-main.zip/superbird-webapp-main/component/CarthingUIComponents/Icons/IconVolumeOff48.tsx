import { IconVolumeOff } from '@spotify-internal/encore-web';

const IconVolume48 = () => <IconVolumeOff iconSize={48} />;

export default IconVolume48;
