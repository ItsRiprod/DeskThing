import { IconSkipForward15 } from '@spotify-internal/encore-web';

const IconSeek15Forward48 = () => <IconSkipForward15 iconSize={48} />;

export default IconSeek15Forward48;
