import { IconPlaybackSpeed0point8x } from '@spotify-internal/encore-web';
const IconPlaybackSpeed0Point8X48 = () => (
  <IconPlaybackSpeed0point8x iconSize={48} />
);
export default IconPlaybackSpeed0Point8X48;
