import { IconPlaybackSpeed2Point5x } from '@spotify-internal/encore-web';

const IconPlaybackSpeed2Point5X48 = () => (
  <IconPlaybackSpeed2Point5x iconSize={48} />
);

export default IconPlaybackSpeed2Point5X48;
