import { IconPlaybackSpeed2x } from '@spotify-internal/encore-web';

const IconPlaybackSpeed2X48 = () => <IconPlaybackSpeed2x iconSize={48} />;

export default IconPlaybackSpeed2X48;
