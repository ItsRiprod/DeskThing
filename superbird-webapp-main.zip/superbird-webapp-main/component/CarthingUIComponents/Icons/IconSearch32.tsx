import { IconSearch } from '@spotify-internal/encore-web';

const IconSearch32 = () => <IconSearch iconSize={32} />;

export default IconSearch32;
