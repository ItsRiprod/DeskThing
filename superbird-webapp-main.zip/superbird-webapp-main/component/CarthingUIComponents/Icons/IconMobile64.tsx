import { IconDeviceMobile } from '@spotify-internal/encore-web';

const IconMobile64 = () => <IconDeviceMobile iconSize={64} />;

export default IconMobile64;
