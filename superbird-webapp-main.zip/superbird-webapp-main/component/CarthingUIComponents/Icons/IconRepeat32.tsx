import { IconRepeat } from '@spotify-internal/encore-web';

const IconRepeat32 = () => <IconRepeat iconSize={32} />;

export default IconRepeat32;
