import { IconHome } from '@spotify-internal/encore-web';

const IconHome32 = () => <IconHome iconSize={32} />;

export default IconHome32;
