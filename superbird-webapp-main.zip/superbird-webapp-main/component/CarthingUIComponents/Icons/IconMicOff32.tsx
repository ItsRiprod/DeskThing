import { IconMicOff } from '@spotify-internal/encore-web';

const IconMicOff32 = () => <IconMicOff iconSize={32} />;

export default IconMicOff32;
