import { IconShuffle } from '@spotify-internal/encore-web';

const IconShuffle48 = () => <IconShuffle iconSize={48} />;

export default IconShuffle48;
