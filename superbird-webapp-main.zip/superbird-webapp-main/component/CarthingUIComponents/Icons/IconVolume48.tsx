import { IconVolume } from '@spotify-internal/encore-web';

const IconVolume48 = () => <IconVolume iconSize={48} />;

export default IconVolume48;
