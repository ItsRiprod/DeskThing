import { IconPlay } from '@spotify-internal/encore-web';

const IconPlay48 = () => <IconPlay iconSize={48} />;

export default IconPlay48;
