import { IconSkipForward } from '@spotify-internal/encore-web';

const IconSkipForward48 = () => <IconSkipForward iconSize={48} />;

export default IconSkipForward48;
