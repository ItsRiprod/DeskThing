import { IconPlaybackSpeed1point2x } from '@spotify-internal/encore-web';

const IconPlaybackSpeed1Point2X48 = () => (
  <IconPlaybackSpeed1point2x iconSize={48} />
);
export default IconPlaybackSpeed1Point2X48;
