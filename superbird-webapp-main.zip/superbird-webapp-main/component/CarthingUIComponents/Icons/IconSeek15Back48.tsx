import { IconSkipBack15 } from '@spotify-internal/encore-web';

const IconSeek15Back48 = () => <IconSkipBack15 iconSize={48} />;

export default IconSeek15Back48;
