import IconShuffleActive from 'component/CarthingUIComponents/Icons/IconShuffleActive';

const IconShuffleActive48 = () => <IconShuffleActive iconSize={48} />;

export default IconShuffleActive48;
