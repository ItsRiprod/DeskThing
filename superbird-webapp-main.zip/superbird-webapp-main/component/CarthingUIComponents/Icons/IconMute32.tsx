import { IconMicOff } from '@spotify-internal/encore-web';

const IconMute32 = () => <IconMicOff iconSize={32} />;

export default IconMute32;
