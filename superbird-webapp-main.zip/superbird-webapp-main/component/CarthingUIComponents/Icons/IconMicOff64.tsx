import { IconMicOff } from '@spotify-internal/encore-web';

const IconMicOff64 = () => <IconMicOff iconSize={64} />;

export default IconMicOff64;
