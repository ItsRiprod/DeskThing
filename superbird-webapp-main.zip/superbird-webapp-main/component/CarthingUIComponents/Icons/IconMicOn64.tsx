import { IconMicrophone } from '@spotify-internal/encore-web';

const IconMicOn64 = () => <IconMicrophone iconSize={64} />;

export default IconMicOn64;
