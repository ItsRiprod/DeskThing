import { IconPlaybackSpeed1x } from '@spotify-internal/encore-web';

const IconPlaybackSpeed1X48 = () => <IconPlaybackSpeed1x iconSize={48} />;

export default IconPlaybackSpeed1X48;
