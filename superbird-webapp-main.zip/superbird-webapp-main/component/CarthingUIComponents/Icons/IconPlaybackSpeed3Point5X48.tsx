import { IconPlaybackSpeed3Point5x } from '@spotify-internal/encore-web';

const IconPlaybackSpeed3Point5X48 = () => (
  <IconPlaybackSpeed3Point5x iconSize={48} />
);

export default IconPlaybackSpeed3Point5X48;
