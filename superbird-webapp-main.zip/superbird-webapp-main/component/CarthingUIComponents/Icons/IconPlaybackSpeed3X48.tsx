import { IconPlaybackSpeed3x } from '@spotify-internal/encore-web';

const IconPlaybackSpeed3X48 = () => <IconPlaybackSpeed3x iconSize={48} />;

export default IconPlaybackSpeed3X48;
