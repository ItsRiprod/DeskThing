import { IconHeartActive } from '@spotify-internal/encore-web';

const IconHeartActive48 = () => <IconHeartActive iconSize={48} />;

export default IconHeartActive48;
