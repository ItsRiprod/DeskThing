import { IconPlusAlt } from '@spotify-internal/encore-web';

const IconAddAlt48 = () => <IconPlusAlt iconSize={48} />;

export default IconAddAlt48;
