import { IconPlaybackSpeed1point5x } from '@spotify-internal/encore-web';

const IconPlaybackSpeed1Point5X48 = () => (
  <IconPlaybackSpeed1point5x iconSize={48} />
);

export default IconPlaybackSpeed1Point5X48;
