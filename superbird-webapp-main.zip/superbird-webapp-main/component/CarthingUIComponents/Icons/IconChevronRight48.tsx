import { IconChevronRight } from '@spotify-internal/encore-web';

const IconChevronRight48 = () => <IconChevronRight iconSize={48} />;

export default IconChevronRight48;
