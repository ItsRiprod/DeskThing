import { IconSkipBack } from '@spotify-internal/encore-web';

const IconSkipBack48 = () => <IconSkipBack iconSize={48} />;

export default IconSkipBack48;
