import { IconCheck } from '@spotify-internal/encore-web';

const IconCheck32 = () => <IconCheck iconSize={32} />;

export default IconCheck32;
