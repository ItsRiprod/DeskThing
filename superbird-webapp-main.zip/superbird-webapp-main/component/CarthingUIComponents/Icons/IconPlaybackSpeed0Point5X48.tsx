import { IconPlaybackSpeed0point5x } from '@spotify-internal/encore-web';

const IconPlaybackSpeed0Point5X48 = () => (
  <IconPlaybackSpeed0point5x iconSize={48} />
);

export default IconPlaybackSpeed0Point5X48;
