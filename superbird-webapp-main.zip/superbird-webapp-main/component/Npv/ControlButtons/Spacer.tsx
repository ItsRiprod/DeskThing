import ControlButton from 'component/Npv/ControlButtons/ControlButton';
import { NpvIcon } from 'component/Npv/ControlButtons/Controls';

const Spacer = () => <ControlButton id={NpvIcon.SPACER} />;

export default Spacer;
