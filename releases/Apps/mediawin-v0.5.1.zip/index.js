var __getOwnPropNames = Object.getOwnPropertyNames;
var __commonJS = (cb, mod) => function __require() {
  return mod || (0, cb[__getOwnPropNames(cb)[0]])((mod = { exports: {} }).exports, mod), mod.exports;
};

// mediawin.js
var require_mediawin = __commonJS({
  "mediawin.js"(exports2, module2) {
    var { exec } = require("child_process");
    var fs = require("fs");
    var path = require("path");
    var MediaWin = class {
      constructor(sendDataToMainFn) {
        this.sendDataToMainFn = sendDataToMainFn;
        this.settings = {
          "refresh_interval": {
            "value": 3e4,
            "label": "Refresh interval",
            "options": [
              {
                "value": 0,
                "label": "Disabled"
              },
              {
                "value": 5e3,
                "label": "5 seconds"
              },
              {
                "value": 3e4,
                "label": "30 seconds"
              }
            ]
          }
        };
        this.cliPath = path.join(__dirname, "DeskThingMediaCLI.exe");
        const manifestPath = path.join(__dirname, "manifest.json");
        this.manifest = JSON.parse(fs.readFileSync(manifestPath, "utf-8"));
        console.log("MediaWin: Manifest loaded:", this.manifest);
      }
      async sendLog(message) {
        this.sendDataToMainFn("log", message);
      }
      async sendError(message) {
        this.sendDataToMainFn("error", message);
      }
      async returnSongData() {
        return new Promise((resolve, reject) => {
          exec(this.cliPath, (error, stdout, stderr) => {
            if (error) {
              console.error(`exec error: ${error}`);
              reject(error);
              return;
            }
            try {
              const musicData = JSON.parse(stdout);
              musicData.photo = "data:image/png;base64," + musicData.photo;
              this.sendLog("Returning song data");
              resolve(musicData);
            } catch (parseError) {
              console.error("Error parsing JSON:", parseError);
              reject(parseError);
            }
          });
        });
      }
      async skipToNext() {
        return new Promise((resolve, reject) => {
          exec(`${this.cliPath} next`, (error, stdout, stderr) => {
            if (error) {
              console.error(`exec error: ${error}`);
              reject(false);
              return;
            }
            try {
              const result = JSON.parse(stdout);
              this.sendLog("Skipped with response", stdout);
              resolve(result.success);
            } catch (parseError) {
              console.error("Error parsing JSON:", parseError);
              reject(false);
            }
          });
        });
      }
      async skipToPrev() {
        return new Promise((resolve, reject) => {
          exec(`${this.cliPath} previous`, (error, stdout, stderr) => {
            if (error) {
              console.error(`exec error: ${error}`);
              reject(false);
              return;
            }
            try {
              const result = JSON.parse(stdout);
              this.sendLog("Skipped with response", stdout);
              resolve(result.success);
            } catch (parseError) {
              console.error("Error parsing JSON:", parseError);
              reject(false);
            }
          });
        });
      }
      async play() {
        return new Promise((resolve, reject) => {
          exec(`${this.cliPath} play`, (error, stdout, stderr) => {
            if (error) {
              console.error(`exec error: ${error}`);
              reject(false);
              return;
            }
            try {
              const result = JSON.parse(stdout);
              this.sendLog("Played with response", stdout);
              resolve(result.success);
            } catch (parseError) {
              console.error("Error parsing JSON:", parseError);
              reject(false);
            }
          });
        });
      }
      async pause() {
        return new Promise((resolve, reject) => {
          exec(`${this.cliPath} pause`, (error, stdout, stderr) => {
            if (error) {
              console.error(`exec error: ${error}`);
              reject(false);
              return;
            }
            try {
              this.sendLog("Paused with response", stdout);
              const result = JSON.parse(stdout);
              resolve(result.success);
            } catch (parseError) {
              console.error("Error parsing JSON:", parseError);
              reject(false);
            }
          });
        });
      }
      async setShuffle(state) {
        return new Promise((resolve, reject) => {
          exec(`${this.cliPath} setshuffle ${state}`, (error, stdout, stderr) => {
            if (error) {
              console.error(`exec error: ${error}`);
              reject(false);
              return;
            }
            try {
              this.sendLog("Set Shuffle with response", stdout);
              const result = JSON.parse(stdout);
              resolve(result.success);
            } catch (parseError) {
              console.error("Error parsing JSON:", parseError);
              reject(false);
            }
          });
        });
      }
      async setRepeat(state) {
        return new Promise((resolve, reject) => {
          exec(`${this.cliPath} setrepeat ${state}`, (error, stdout, stderr) => {
            if (error) {
              console.error(`exec error: ${error}`);
              reject(false);
              return;
            }
            try {
              this.sendLog("Set Repeat with response", stdout);
              const result = JSON.parse(stdout);
              resolve(result.success);
            } catch (parseError) {
              console.error("Error parsing JSON:", parseError);
              reject(false);
            }
          });
        });
      }
      async seek(position_ms) {
        return new Promise((resolve, reject) => {
          exec(`${this.cliPath} seek ${position_ms}`, (error, stdout, stderr) => {
            if (error) {
              console.error(`exec error: ${error}`);
              sendError(`exec error: ${error}`);
              reject(false);
              return;
            }
            try {
              this.sendLog("Seeked with response", stdout);
              const result = JSON.parse(stdout);
              resolve(result.success);
            } catch (parseError) {
              console.error("Error parsing JSON:", parseError);
              reject(false);
            }
          });
        });
      }
    };
    module2.exports = MediaWin;
  }
});

// index.js
var MediaWinHandler = require_mediawin();
var mediawin;
async function start({ sendDataToMain }) {
  console.log("MediaWin App started!");
  mediawin = new MediaWinHandler(sendDataToMain);
  sendDataToMain("get", "data");
  mediawin.sendLog("Successfully Started!");
}
async function stop() {
  console.log("MediaWin App stopping...");
  mediawin.sendLog("Successfully Stopped!");
  mediawin = null;
}
async function onMessageFromMain(event, ...args) {
  console.log(`MEDIAWIN: Received event ${event} with args `, ...args);
  try {
    switch (event) {
      case "message":
        break;
      case "data":
        if (args[0].settings) {
          mediawin.settings = args[0].settings;
        } else {
          const settings = { settings: mediawin.settings };
          mediawin.sendDataToMainFn("add", settings);
        }
        break;
      case "get":
        handleGet(...args);
        break;
      case "set":
        handleSet(...args);
        break;
      default:
        console.log("MEDIAWIN: Unknown message:", event, ...args);
        mediawin.sendError(`Unknown Message received ${event} ${args[0]}`);
        break;
    }
  } catch (error) {
    console.error("MEDIAWIN: Error in onMessageFromMain:", error);
  }
}
var handleGet = async (...args) => {
  console.log("MEDIAWIN: Handling GET request", ...args);
  if (args[0] == null) {
    console.log("MEDIAWIN: No args provided");
    return;
  }
  let response;
  switch (args[0].toString()) {
    case "song_info":
      response = await mediawin.returnSongData();
      mediawin.sendDataToMainFn("data", { type: "song_data", data: response });
      break;
    case "device_info":
      response = await mediawin.returnSongData();
      mediawin.sendDataToMainFn("data", { type: "song_data", data: response });
      break;
    case "manifest":
      response = mediawin.manifest;
      mediawin.sendDataToMainFn("manifest", response);
      break;
    default:
      response = `${args[0].toString()} Not implemented yet!`;
      break;
  }
  mediawin.sendDataToMainFn("data", response);
};
var handleSet = async (...args) => {
  console.log("MEDIAWIN: Handling SET request", ...args);
  if (args[0] == null) {
    console.log("MEDIAWIN: No args provided");
    return;
  }
  let response;
  switch (args[0].toString()) {
    case "set_vol":
      response = await mediawin.setVolume(args[1]);
      break;
    case "set_shuffle":
      response = await mediawin.setShuffle(args[1]);
      break;
    case "set_repeat":
      response = await mediawin.setRepeat(args[1]);
      break;
    case "next_track":
      response = await mediawin.skipToNext(args[1]);
      response = await mediawin.returnSongData();
      mediawin.sendDataToMainFn("data", { type: "song_data", data: response });
      break;
    case "previous_track":
      response = await mediawin.skipToPrev(args[1]);
      response = await mediawin.returnSongData();
      mediawin.sendDataToMainFn("data", { type: "song_data", data: response });
      break;
    case "pause_track":
    case "stop_track":
      response = await mediawin.pause();
      break;
    case "seek_track":
      response = await mediawin.seek(args[1]);
      break;
    case "play_track":
      response = await mediawin.play();
      response = await mediawin.returnSongData();
      mediawin.sendDataToMainFn("data", { type: "song_data", data: response });
      break;
    case "update_setting":
      if (args[1] != null) {
        const { setting, value } = args[1];
        mediawin.settings[setting].value = value;
        console.log("MEDIAWIN New Setting", mediawin.settings);
        response = { settings: mediawin.settings };
        mediawin.sendDataToMainFn("add", response);
      } else {
        console.log("MEDIAWIN: No args provided", args[1]);
        response = "No args provided";
      }
      break;
  }
  mediawin.sendDataToMainFn("data", response);
};
module.exports = { start, onMessageFromMain, stop };
