var __getOwnPropNames = Object.getOwnPropertyNames;
var __commonJS = (cb, mod) => function __require() {
  return mod || (0, cb[__getOwnPropNames(cb)[0]])((mod = { exports: {} }).exports, mod), mod.exports;
};

// mediawin.js
var require_mediawin = __commonJS({
  "mediawin.js"(exports2, module2) {
    var { exec } = require("child_process");
    var fs = require("fs");
    var path = require("path");
    var MediaWin = class {
      constructor(sendDataToMainFn) {
        this.sendDataToMainFn = sendDataToMainFn;
        this.settings = {
          "refresh_interval": {
            "value": 3e4,
            "label": "Refresh interval",
            "options": [
              {
                "value": 0,
                "label": "Disabled"
              },
              {
                "value": 5e3,
                "label": "5 seconds"
              },
              {
                "value": 3e4,
                "label": "30 seconds"
              }
            ]
          }
        };
        this.cliPath = path.join(__dirname, "DeskThingMediaCLI.exe");
        const manifestPath = path.join(__dirname, "manifest.json");
        this.manifest = JSON.parse(fs.readFileSync(manifestPath, "utf-8"));
        this.sendLog("Manifest loaded:", this.manifest);
      }
      async sendLog(message) {
        this.sendDataToMainFn("log", message);
      }
      async sendError(message) {
        this.sendDataToMainFn("error", message);
      }
      async returnSongData() {
        const result = await this.executeCommand("");
        if (result === false) {
          this.sendError("Music Data returned false! There was an error");
          return false;
        } else {
          const musicData = result;
          musicData.thumbnail = "data:image/png;base64," + musicData.thumbnail;
          musicData.volume = await this.getVolumeInfo();
          musicData.can_change_volume = true;
          this.sendLog("Returning song data");
          return musicData;
        }
      }
      async executeCommand(command, args = "") {
        return new Promise((resolve, reject) => {
          exec(`${this.cliPath} ${command} ${args}`, (error, stdout, stderr) => {
            if (error) {
              this.sendError(`exec error: ${error}`);
              reject(false);
              return;
            }
            try {
              const result = JSON.parse(stdout);
              this.sendLog(`${command} with response` + stdout);
              resolve(result);
            } catch (parseError) {
              this.sendError("Error parsing JSON:" + parseError);
              reject(false);
            }
          });
        });
      }
      async exeVol(...args) {
        const executablePath = path.join(__dirname, "adjust_get_current_system_volume_vista_plus.exe");
        return new Promise((resolve, reject) => {
          exec(`${executablePath} ${args}`, (error, stdout, stderr) => {
            if (error) {
              this.sendError(`exec error: ${error}`);
              reject(false);
              return;
            }
            try {
              resolve(stdout);
            } catch (parseError) {
              this.sendError("Error parsing JSON:" + parseError);
              reject(false);
            }
          });
        });
      }
      async getVolumeInfo() {
        const data = await this.exeVol();
        const args = data.split(" ");
        return parseInt(args[0], 10);
      }
      async next() {
        return this.executeCommand("next");
      }
      async previous() {
        return this.executeCommand("previous");
      }
      async fastForward(seconds) {
        return this.executeCommand("fastforward", seconds);
      }
      async rewind(seconds) {
        return this.executeCommand("rewind", seconds);
      }
      async play() {
        return this.executeCommand("play");
      }
      async pause() {
        return this.executeCommand("pause");
      }
      async stop() {
        return this.executeCommand("stop");
      }
      async seek(positionMs) {
        return this.executeCommand("seek", positionMs);
      }
      async volume(volumePercentage) {
        this.exeVol(String(volumePercentage));
        return true;
      }
      async repeat(state) {
        return this.executeCommand("setrepeat", state);
      }
      async shuffle(state) {
        return this.executeCommand("setshuffle", state);
      }
    };
    module2.exports = MediaWin;
  }
});

// index.js
var MediaWinHandler = require_mediawin();
var mediawin;
async function start({ sendDataToMain }) {
  mediawin = new MediaWinHandler(sendDataToMain);
  sendDataToMain("get", "data");
  mediawin.sendLog("Successfully Started!");
}
async function stop() {
  mediawin.sendLog("Successfully Stopped!");
  mediawin = null;
}
async function onMessageFromMain(event, ...args) {
  mediawin.sendLog(`MEDIAWIN: Received event ${event}`);
  try {
    switch (event) {
      case "message":
        break;
      case "data":
        if (args[0]?.settings != null) {
          mediawin.settings = args[0].settings;
        } else {
          const settings = { settings: mediawin.settings };
          mediawin.sendDataToMainFn("add", settings);
        }
        break;
      case "get":
        handleGet(...args);
        break;
      case "set":
        handleSet(...args);
        break;
      default:
        mediawin.sendError(`Unknown Message received ${event} ${args[0]}`);
        break;
    }
  } catch (error) {
    mediawin.sendError("Error in onMessageFromMain:", error);
  }
}
var handleGet = async (...args) => {
  if (args[0] == null) {
    mediawin.sendError("No args provided");
    return;
  }
  let response;
  switch (args[0].toString()) {
    case "song":
      response = await mediawin.returnSongData();
      response = { type: "song", data: response };
      break;
    case "manifest":
      response = mediawin.manifest;
      mediawin.sendDataToMainFn("manifest", response);
      break;
    default:
      response = `${args[0].toString()} Not implemented yet!`;
      break;
  }
  mediawin.sendDataToMainFn("data", response);
};
var handleSet = async (...args) => {
  if (args[0] == null) {
    mediawin.sendError("No args provided");
    return;
  }
  let response;
  switch (args[0].toString()) {
    case "next":
      response = await mediawin.next(args[1]);
      break;
    case "previous":
      response = await mediawin.previous();
      break;
    case "fast_forward":
      response = await mediawin.fastForward(args[1]);
      break;
    case "rewind":
      response = await mediawin.rewind(args[1]);
      break;
    case "play":
      response = await mediawin.play(args[1]);
      break;
    case "pause":
    case "stop":
      response = await mediawin.pause();
      break;
    case "seek":
      response = await mediawin.seek(args[1]);
      break;
    case "like":
      response = "Unable to like songs!";
      break;
    case "volume":
      response = await mediawin.volume(args[1]);
      break;
    case "repeat":
      response = await mediawin.repeat(args[1]);
      break;
    case "shuffle":
      response = await mediawin.shuffle(args[1]);
      break;
    case "update_setting":
      if (args[1] != null) {
        const { setting, value } = args[1];
        mediawin.settings[setting].value = value;
        mediawin.sendLog("MEDIAWIN New Setting", mediawin.settings);
        response = { settings: mediawin.settings };
        mediawin.sendDataToMainFn("add", response);
      } else {
        response = "No args provided";
      }
      break;
  }
  mediawin.sendDataToMainFn("data", response);
};
module.exports = { start, onMessageFromMain, stop };
